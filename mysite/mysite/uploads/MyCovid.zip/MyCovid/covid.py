import sys
from main import Covid, IllOrDead, Territory, Time, SortBy

c = Covid("C:/Users/iwoza/OneDrive/Documents/lab4Scrypt/Covid.txt")
c.load()
c.worst_days(IllOrDead.DEAD, Territory.COUNTRY, "France", Time.DAY, "10.08.2020", SortBy.ILL)
print()
c.worst_days(IllOrDead.DEAD, Territory.CONTINENT, "Africa", Time.DAY, "10.08.2020", SortBy.ILL)
c.worst_days(IllOrDead.ILL, Territory.WORLD, None, Time.ALL, None, SortBy.ILL, 7)
