import sys
from main import Covid, IllOrDead, Territory, Time, SortBy

def work():
    c = Covid("C:/Users/iwoza/OneDrive/Documents/lab4Scrypt/Covid.txt")
    c.load()
    command=""
    while command!="end":
        command = input("Enter your command, if you want help press help, to finish type end:  ")
        if command == "help":
            print("To find what are you looking for follow this scheme:")
            print("find [dead | ill] [/C | /W | /T] [ ... |   | ...] [/D | /M | /A] [... | 1-12 |  ] [/DD | /IL | /AL] 1")
            print("/C - country, /T - continent, /W - world, ... - given name, "   " - leave empty")
            print("/D- precise date, /M- month, /A - all dates, /DD - sort by deaths, /IL - sort by ill, /AL - aphabetic order, 1 - maximum number of results, optional")
            print("Example: find ill /C Poland /M 7 /IL 10")
            print("Example: find dead /T Africa /D 11.08.2020 /DD")
            print("Example: find dead /W /A /AL")
        if command =="end":
            break
        else:
            incomming_message(command, c)

def incomming_message(command, cov):
    parameter_list = list()
    iterator = 0
    command_splitted = command.split(" ")
    if command_splitted[iterator] == "find":
        iterator +=1
        values = set(item.value for item in IllOrDead)
        if command_splitted[iterator] == "dead" or command_splitted[iterator] == "ill":
            if command_splitted[iterator] == "dead":
                parameter_list.append(IllOrDead.DEAD)
            if command_splitted[iterator] == "ill":
                parameter_list.append(IllOrDead.ILL)
            iterator += 1
            if command_splitted[iterator] == "/C" or command_splitted[iterator] == "/W" or command_splitted[iterator] == "/T":
                if command_splitted[iterator] == "/C":
                    parameter_list.append(Territory.COUNTRY)
                    iterator += 1
                    parameter_list.append(command_splitted[iterator])
                    iterator += 1
                if command_splitted[iterator] == "/W":
                    parameter_list.append(Territory.WORLD)
                    iterator +=1
                    parameter_list.append(None)
                if command_splitted[iterator] == "/T":
                    parameter_list.append(Territory.CONTINENT)
                    iterator += 1
                    parameter_list.append(command_splitted[iterator])
                    iterator += 1
                if command_splitted[iterator] == "/D" or command_splitted[iterator] == "/M" or command_splitted[iterator] == "/A":
                    if command_splitted[iterator] == "/D":
                        parameter_list.append(Time.DAY)
                        iterator += 1
                        parameter_list.append(command_splitted[iterator])
                        iterator += 1
                    if command_splitted[iterator] == "/A":
                        parameter_list.append(Time.ALL)
                        iterator +=1
                        parameter_list.append(None)
                    if command_splitted[iterator] == "/M":
                        parameter_list.append(Time.MONTH)
                        iterator += 1
                        parameter_list.append(command_splitted[iterator])
                        iterator += 1
                    if command_splitted[iterator] == "/DD" or command_splitted[iterator] == "/IL" or command_splitted[iterator] == "/AL":
                        if command_splitted[iterator] == "/DD":
                            parameter_list.append(SortBy.DEAD)
                        if command_splitted[iterator] == "/IL":
                            parameter_list.append(SortBy.ILL)
                        if command_splitted[iterator] == "/AL":
                            parameter_list.append(SortBy.COUNTRY)
                        iterator+=1
                        try:
                            cov.worst_days(parameter_list[0], parameter_list[1], parameter_list[2], parameter_list[3], parameter_list[4], parameter_list[5], int(command_splitted[iterator]))
                        except:
                            cov.worst_days(parameter_list[0], parameter_list[1], parameter_list[2], parameter_list[3], parameter_list[4], parameter_list[5])
                    else:
                        print("Wrong switch was chosen (/DD means dead, /IL means month and /AL means all time")
                else:
                    print("Wrong switch was chosen (/D means day, /M means month and /A means all time")

            else:
                print("Wrong switch was chosen (/C means country, /W means word and /T means continent")
        else:
            print("Wrong parameter was chosen, choose dead or ill")
    else:
        print("Wrong prefix of command")




work()