import sys
from tkinter import *
from tkinter import messagebox, IntVar
from main import Covid, IllOrDead, Territory, Time, SortBy


class I2:
    def __init__(self):
        self.__ilOrDead = IllOrDead
        self.__territory = Territory
        self.__territory_name = None
        self.__time = Time
        self.__date = None
        self.__sort_by = SortBy
        self.__elements = 4
        self.__covid_obj = Covid("C:/Users/iwoza/OneDrive/Documents/lab4Scrypt/Covid.txt")
        self.__covid_obj.load()

    def my_gui(self):
        window = Tk()
        window.title( "Find Covid cases" )
        window.geometry( '700x350')
        selected_dead_or_ill = IntVar()
        selected_territory = IntVar()
        selected_time = IntVar()
        selected_sort = IntVar()
        def set_ill_or_dead():
            if selected_dead_or_ill.get() == 1:
                self.__ilOrDead = IllOrDead.ILL
            if selected_dead_or_ill.get() == 2:
                self.__ilOrDead = IllOrDead.DEAD
        def set_territory():
            if selected_territory.get() == 1:
                self.__territory = Territory.COUNTRY
            if selected_territory.get() == 2:
                self.__territory = Territory.CONTINENT
            if selected_territory.get() == 3:
                self.__territory = Territory.WORLD
        def set_time():
            if selected_time.get() == 1:
                self.__time = Time.DAY
            if selected_time.get() == 2:
                self.__time = Time.MONTH
            if selected_time.get() == 3:
                self.__time = Time.ALL
        def set_sort():
            if selected_sort.get() == 1:
                self.__sort_by = SortBy.DEAD
            if selected_sort.get() == 2:
                self.__sort_by = SortBy.ILL
            if selected_sort.get() == 3:
                self.__sort_by = SortBy.COUNTRY
        def look():
           val = self.__covid_obj.worst_days(self.__ilOrDead, self.__territory, territory_enter.get(), self.__time, date_enter.get(), self.__sort_by, self.__elements)
           if val=="":
                messagebox.showinfo('Found', "Not found")
           else:
               messagebox.showinfo('Found', val)
        def add_to_path():
            def set_covid():
                covid=Covid(path.get())
                if covid.load():
                    self.__covid_obj=covid
                    messagebox.showinfo ( "Done", "Path added" )
                else:
                    messagebox.showinfo ( "Wrong path", "UPS..." )
                newwindow.destroy()

            newwindow = Tk()
            newwindow.title ( "Enter valid path" )
            newwindow.geometry ( '300x200' )
            L1 = Label ( newwindow, text="Valid PATH" )
            path = Entry ( newwindow, width=30)
            path.grid(column=3, row=2)
            L1.grid ( column=2, row=2)
            newbutton = Button(newwindow,anchor=SE, text="SET", command=set_covid)
            newbutton.grid(column=3, row=5)
            newwindow.mainloop()
        def set_ammount():
            def set_elements():
                self.__elements=int(val.get())
                print(self.__elements)
                messagebox.showinfo ( "Done", "Value changed" )
                newwindow2.destroy()
            newwindow2 = Tk()
            newwindow2.title ( "Enter output data quantity" )
            newwindow2.geometry ( '300x200' )
            L2 = Label ( newwindow2, text="Quantity" )
            val = Spinbox(newwindow2, from_=0, to=100, width=8)
            val.grid(column=3, row=2)
            L2.grid ( column=2, row=2)
            newbutton2 = Button(newwindow2,anchor=SE, text="SET", command=set_elements)
            newbutton2.grid(column=3, row=5)
            newwindow2.mainloop()
        look_for = Button(window, text="Look for", command=look)
        rad_ill_or_dead = Radiobutton(window, text='ILL ',anchor=W, value=1, variable=selected_dead_or_ill, command=set_ill_or_dead, width=10)
        rad_ill_or_dead2 = Radiobutton(window, text='DEAD',anchor=W, value=2, variable=selected_dead_or_ill, command=set_ill_or_dead,width=10)
        rad_territory = Radiobutton(window, text='Country ',anchor=W, value=1, variable=selected_territory, command=set_territory, width=10)
        rad_territory2 = Radiobutton(window, text='Continet',anchor=W, value=2, variable=selected_territory, command=set_territory, width=10)
        rad_territory3 = Radiobutton(window, text='World  ',anchor=W, value=3, variable=selected_territory, command=set_territory, width=10)
        rad_time = Radiobutton(window, text='Day  ',anchor=W, value=1, variable=selected_time, command=set_time, width=10)
        rad_time2 = Radiobutton(window, text='Month', anchor=W, value=2, variable=selected_time, command=set_time, width=10)
        rad_time3 = Radiobutton(window, text='All  ', anchor=W,value=3, variable=selected_time, command=set_time, width=10)
        rad_sort = Radiobutton(window, text='Dead', anchor=W,value=1, variable=selected_sort, command=set_sort,width=10)
        rad_sort2 = Radiobutton(window, text='ILL', anchor=W,value=2, variable=selected_sort, command=set_sort,width=10)
        rad_sort3 = Radiobutton(window, text='Alphabetic',anchor=W, value=3, variable=selected_sort, command=set_sort,width=10)
        territory_enter = Entry(window, width=10)
        date_enter = Entry(window,width=10)
        #how_many = Entry(window, width=10)
        rad_ill_or_dead.grid(column=0, row=2)
        #rad_ill_or_dead.pack(anchor = W)
        rad_ill_or_dead2.grid(column=0, row=4)
        #rad_ill_or_dead2.pack ( anchor=W )
        rad_territory.grid(column=1, row=2)
        rad_territory2.grid(column=1, row=3)
        rad_territory3.grid(column=1, row=4)
        territory_enter.grid(column=2, row=3)
        rad_time.grid(column=3, row=2)
        rad_time2.grid(column=3, row=3)
        rad_time3.grid(column=3, row=4)
        date_enter.grid(column=4, row=3)
        rad_sort.grid(column=5, row=2)
        rad_sort2.grid(column=5, row=3)
        rad_sort3.grid(column=5, row=4)
        look_for.grid(column=6, row=8)
        first_text = Label ( window, text="Choose category", background='red' )
        first_text.grid ( column=0, row=1 )
        second_text = Label ( window, text="Choose teritory", background='blue' )
        second_text.grid ( column=1, row=1 )
        third_text = Label ( window, text="Teritory name", background='red' )
        third_text.grid ( column=2, row=1 )
        forth_text = Label ( window, text="Time interval", background='blue' )
        forth_text.grid ( column=3, row=1 )
        fith_text = Label ( window, text="Date or month", background='red' )
        fith_text.grid ( column=4, row=1 )
        sixth_text = Label ( window, text="Sort by", background='blue' )
        sixth_text.grid ( column=5, row=1 )
        menubar = Menu(window)
        filemenu = Menu(menubar, tearoff=0)
        filemenu.add_command(label="Add path", command=add_to_path)
        filemenu.add_command(label="Amount ", command=set_ammount)
        filemenu.add_command(label="Close", command=quit)
        menubar.add_cascade(label="File", menu=filemenu)
        window.config(menu=menubar)
        window.mainloop()


c = I2()
c.my_gui()

