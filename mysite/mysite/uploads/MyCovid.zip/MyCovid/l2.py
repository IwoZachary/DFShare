from main import Covid, IllOrDead, Territory, Time, SortBy
import os
from time import sleep

def work():
    covid_obj = Covid("Covid.txt")
    covid_obj.load()
    while True:
        print ( "Welcome to COVID_FINDER" )
        parameter_seq=list()
        parameter_seq, able_to_continue = input1(parameter_seq)
        if able_to_continue==True:
            parameter_seq, able_to_continue = input2(parameter_seq)
            if able_to_continue==True:
                parameter_seq, able_to_continue = input3(parameter_seq)
                if able_to_continue == True:
                    parameter_seq, able_to_continue = input4 ( parameter_seq )
                    if able_to_continue == True:
                        covid_obj.worst_days ( *parameter_seq, 7 )
                        able_to_continue = input5()
                        _ = os.system ( "cls" )
                        if able_to_continue == False:
                            break
                    else:

                        continue
                else:

                    continue
            else:

                continue
        else:

            continue

def input1(parameter_seq):
    my_input = input ( "Enter ILL or DEAD to chose what you want to see on display: " )
    my_input = my_input.upper()
    done=True

    if my_input == "DEAD":
        parameter_seq.append ( IllOrDead.DEAD )

    elif my_input == "ILL":
        parameter_seq.append ( IllOrDead.ILL )

    else:
        print ( "Wrong option, only DEAD or ILL is valid" )
        done=False

    _ = os.system("cls")
    return parameter_seq, done

def input2(parameter_seq):
    my_input = input( "Enter WORLD to choose data from whole world,\n CONTINENT to see data from continent,\n or country to see data from COUNTRY: " )
    my_input = my_input.upper()
    done=True

    if my_input == "WORLD":
        parameter_seq.append(Territory.WORLD)
        parameter_seq.append(None)
    elif my_input == "CONTINENT":
        parameter_seq.append(Territory.CONTINENT)
        input_v=input("Enter continet name: ")
        parameter_seq.append(input_v)
    elif my_input == "COUNTRY":
        parameter_seq.append ( Territory.COUNTRY)
        input_v = input ( "Enter country name: " )
        parameter_seq.append ( input_v )
    else:
        print ( "Wrong option only WORLD, CONTINET or COUNTRY is valid" )
        done= False
    _ = os.system ( "cls" )
    return parameter_seq, done

def input3(parameter_seq):
    my_input = input (
        "Enter ALL to gain acces to all dates,\n MONTH to look inside month,\n or DAY to look inside specific date: " )
    my_input=my_input.upper()
    done = True
    if my_input == "ALL":
        parameter_seq.append ( Time.ALL )
        parameter_seq.append ( None )
    elif my_input == "MONTH":
        parameter_seq.append ( Time.MONTH )
        input_v2 = input ( "Enter number in range 1-12 representing month number: " )
        parameter_seq.append ( input_v2 )
    elif my_input == "DAY":
        parameter_seq.append ( Time.DAY )
        input_v2 = input ( "Enter date in format 00.00.0000: " )
        parameter_seq.append ( input_v2 )
    else:
        print ( "Wrong parameter only ALL, MONTH or DAY are valid" )
        done= False
    _ = os.system ( "cls" )
    return parameter_seq, done

def input4(parameter_seq):
    my_input = input (
        "Type ILL to sort by cases,\n type DEAD to sort by casualities,\n or type ALPHA for alphabetic order: " )
    my_input = my_input.upper()
    done=True
    if my_input == "ILL":
        parameter_seq.append ( SortBy.ILL )
    elif my_input == "DEAD":
        parameter_seq.append ( SortBy.DEAD )
    elif my_input == "ALPHA":
        parameter_seq.append ( SortBy.COUNTRY )
    else:
        print ( "Wrong parameter, only ILL, DEAD or ALPHA are valid" )
        done=False
    _ = os.system ( "cls" )
    return parameter_seq, done

def input5():
    my_input = input("If you want to continue type y, type anything to quit: ")
    my_input=my_input.upper()
    if my_input == "Y" :
        return True
    else:
        return False

work()