from enum import Enum
class Covid:
    def __init__(self, fileName):
        self.__fileName = fileName
        self.__list_of_covid = list()

    def load(self):
        try:
            file = open(self.__fileName, "rt", encoding="utf-8")
            next(file)
            for line in file:
                line.replace("\n", "")
                splitted = line.split("\t")
                self.__list_of_covid.append(splitted)

            return True
        except FileNotFoundError:
            print("Error while loading a file")
            return False

    def __levenstein(self, str1, str2):
        arr = []
        for i in range(0, len(str1) + 1):
            arr.append([])
            for j in range(0, len(str2) + 1):
                arr[i].append(0)

        for i in range(0, len(str1) + 1):
            arr[i][0] = i
        for i in range(0, len(str2) + 1):
            arr[0][i] = i

        for i in range(1, len(str1) + 1):
            for j in range(1, len(str2) + 1):
                price = 1
                if str1[i - 1] == str2[j - 1]:
                    price = 0
                arr[i][j] = min(arr[i - 1][j] + 1, arr[i][j - 1] + 1, arr[i - 1][j - 1] + price)

        return arr[len(arr) - 1][len(arr[0]) - 1]

    def worst_days(self, il_or_dead, territory, territory_name, time, time_name, sort_by, ammount=4):
        work_list = list()
        buffer=""
        if territory.name != "WORLD" and time.name != "ALL":
            for el in self.__list_of_covid:
                if el[territory.value] == territory_name and el[time.value] == time_name:
                    work_list.append(el)
        if territory.name == "WORLD" and time.name == "ALL":
            work_list = self.__list_of_covid
        if territory.name == "WORLD" and time.name != "ALL":
            for el in self.__list_of_covid:
                if el[time.value] == time_name:
                    work_list.append(el)
        if territory.name != "WORLD" and time.name == "ALL":
            for el in self.__list_of_covid:
                if el[territory.value] == territory_name:
                    work_list.append(el)
        if sort_by.name == "COUNTRY":
            work_list.sort(key=lambda el: el[sort_by.value])
        if sort_by.name != "COUNTRY":
            work_list.sort(key=lambda el: int(el[sort_by.value]), reverse = True)
        if ammount>=len(work_list):
            for el in work_list:
                buffer+=str(el[il_or_dead.value])+" "+str(el[0])+" "+str(el[6])+" "+str(el[10])+"\n"
                print(str(el[il_or_dead.value])+" "+str(el[0])+" "+str(el[6])+" "+str(el[10]))
        if ammount<len(work_list):
            for i in range (0,ammount):
                el=work_list[i]
                buffer += str ( el[il_or_dead.value] ) + " " + str ( el[0] ) + " " + str ( el[6] ) + " " + str (el[10] ) + "\n"
                print(str(el[il_or_dead.value]) + " " + str(el[0]) + " " + str(el[6]) + " " + str(el[10]))
        return buffer







class IllOrDead(Enum):
    DEAD = 5
    ILL = 4

class Territory(Enum):
    COUNTRY = 6
    CONTINENT = 10
    WORLD = 115

class Time(Enum):
    DAY = 0
    MONTH = 2
    ALL = 115

class SortBy(Enum):
    DEAD = 5
    ILL = 4
    COUNTRY = 6





